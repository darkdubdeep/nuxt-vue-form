<template>
  <section class="container">
    <div>
      <app-form/>
    </div>
  </section>
</template>

<script>
import AppForm from "~/components/AppForm.vue";

export default {
  components: {
    AppForm
  }
};
</script>

<style>
</style>

